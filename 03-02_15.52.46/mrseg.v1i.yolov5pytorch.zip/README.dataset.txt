# mrseg > 2022-11-28 5:56pm
https://universe.roboflow.com/mrseg/mrseg

Provided by a Roboflow user
License: CC BY 4.0

