# dlmr > 2022-11-26 12:41am
https://universe.roboflow.com/dtu-3wfzd/dlmr

Provided by a Roboflow user
License: CC BY 4.0

